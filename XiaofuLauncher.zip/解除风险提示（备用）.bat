@echo off
chcp 65001 >nul
title 备用：解除安全锁定

echo.
echo  提示：XiaofuLauncher 现在会【自动】清除自身的网络下载标记，
echo        正常情况下你无需运行本脚本。
echo.
echo  本脚本仅作备用：若首次启动仍被 SmartScreen 拦截，运行一次即可。
echo.
echo  正在解除...
powershell -NoProfile -Command "Get-ChildItem -Path '%~dp0' -Recurse | Unblock-File"
echo  完成。
echo.
pause
